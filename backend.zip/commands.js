const { spawn } = require('child_process');

const runCommandInDirectory = (directory, command) => {
    // console.log(directory, command)
    return new Promise((resolve, reject) => {
      const childProcess = spawn(command, {
        shell: true,
        cwd: directory
      });
  
      let output = '';

      if(command==='exit'){
        setTimeout(function() {
          childProcess.kill('SIGINT');
        }, 1000);  
      }

      childProcess.stdout.on('data', (data) => {
        output += data.toString();
      });
  
      childProcess.stderr.on('data', (data) => {
        output += data.toString();
      });
  
      childProcess.on('close', (code) => {
        resolve({
          output,
          code
        });
      });
      
    });
  };
  
  module.exports = runCommandInDirectory;

// const runCommands = (commands) => {
//   return new Promise((resolve, reject) => {
//     const outputs = [];
//     let index = 0;

//     const executeCommand = () => {
//       if (index >= commands.length) {
//         resolve(outputs);
//         return;
//       }

//       const command = commands[index];
//       const [commandName, ...args] = command.split(' ');

//       const childProcess = spawn(commandName, args);

//       let output = '';

//       childProcess.stdout.on('data', (data) => {
//         output += data.toString();
//       });

//       childProcess.stderr.on('data', (data) => {
//         output += data.toString();
//       });

//       childProcess.on('close', (code) => {
//         outputs.push({
//           command,
//           output,
//           code
//         });

//         index++;
//         executeCommand();
//       });
//     };

//     executeCommand();
//   });
// };

// module.exports = runCommands;
