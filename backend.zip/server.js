const express = require('express');
// const { spawn } = require('child_process');
const cors = require('cors');
const fileUpload = require('express-fileupload');
const runCommandInDirectory = require('./commands');

const app = express();
app.use(
    cors({
      origin: 'http://localhost:3000',
      credentials: true,
    })
);
const port = 5000;

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(fileUpload());
// const router = express.Router();

// app.use(function (req, res, next) {
//     res.header("Access-Control-Allow-Origin", "*");
//     res.header(
//       "Access-Control-Allow-Headers",
//       "Origin, X-Requested-With, Content-Type, Accept"
//     );
//     next();
// });

app.post('/upload', (req, res) => {
  // const file = req.files.file;
  console.log("+++++", req.files.path)
 
});

app.post('/execute', async (req, res) => {
    
    const { directory, command } = req.body;  
    // console.log('********',directory, command);  
    try {
      const result = await runCommandInDirectory(directory, command);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'An error occurred while executing the command.' });
    }
});

app.post('/stop', async (req, res) => {
    
  const { directory, command } = req.body;
  try {
    const result = await runCommandInDirectory(directory, command);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred while executing the command.' });
  }
});

// app.post('/execute', async (req, res) => {
//     const { commands } = req.body;
    
//     try {
//         const outputs = await runCommands(commands);console.log(outputs)
//         res.json(outputs);
//     } catch (error) {
//         res.status(500).json({ error: 'An error occurred while executing the commands.' });
//     }
// });
  
app.listen(port, () => {
console.log(`Server running on port ${port}`);
});

// Get all posts
// app.get('/list', (req, res) => {
//     console.log('11111111')
// });


// app.post('/execute', (req, res) => {
//     const { command } = req.body;
//     const terminalProcess = spawn('bash', ['-c', command]);
  
//     let output = '';
  
//     terminalProcess.stdout.on('data', (data) => {
//       output += data.toString();
//     });
  
//     terminalProcess.stderr.on('data', (data) => {
//       output += data.toString();
//     });
  
//     terminalProcess.on('close', () => {
//       res.send({ output });
//     });
// });

// app.post('/execute', (req, res) => {
    
//     const { commands } = req.body;
//     const output = [];
    
//     const executeCommand = (command) => {
        
//       return new Promise((resolve, reject) => {
//         const [commandName, ...args] = command.split(' ');
//         const childProcess = spawn(commandName, args);
  
//         let commandOutput = '';
  
//         childProcess.stdout.on('data', (data) => {
//           commandOutput += data.toString();
//         });
  
//         childProcess.stderr.on('data', (data) => {
//           commandOutput += data.toString();
//         });
  
//         childProcess.on('close', (code) => {
//           if (code === 0) {
//             output.push({ command, output: commandOutput });
//             resolve();
//           } else {
//             reject(new Error(`Command '${command}' failed with exit code ${code}.`));
//           }
//         });
//       });
//     };
  
//     const executeAllCommands = async () => {
//       try {
//         for (const command of commands) {
//           await executeCommand(command);
//         }
//         console.log('******output', output)
//         res.json({ output });
//       } catch (error) {
//         console.log('******error', error.message)
//         res.status(500).json({ error: error.message });
//       }
//     };
  
//     executeAllCommands();
// });

// app.listen(port, () =>{
//     console.log(`Server running on port ${port}`);
// });