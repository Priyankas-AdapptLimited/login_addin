import React from 'react';
import './App.css'
import CommandRunner from './CommandRunner';

const App = () => {
  return (
    <div class="container">
      <h4 class="text-center">Automation Runner</h4>
      <CommandRunner />
    </div>
  );
};

export default App;


// import React, {useState} from 'react';
// import axios from 'axios'
// axios.defaults.baseURL = 'http://localhost:5000/';
// axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
// const App = () => {
//   const [command, setCommand] = useState('');
//   const [output, setOutput] = useState('');

//   const executeCommand = async () => {
//     try {
//       const response = await axios.post('/execute', { command });
//       setOutput(response.data.output);
//     } catch (error) {
//       console.error(error);
//     }
//   };

//   return (
//     <div>
//       <h1>Interactive Terminal</h1>
//       <input
//         type="text"
//         value={command}
//         onChange={(e) => setCommand(e.target.value)}
//       />
//       <button onClick={executeCommand}>Run</button>
//       <pre>{output}</pre>
//     </div>
//   );
// };

// export default App;
