import React, { useState } from 'react';
import axios from 'axios';
axios.defaults.baseURL = 'http://localhost:5000';
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
const CommandRunner = () => {
  const [command, setCommand] = useState('');
  const [output, setOutput] = useState([]);

  const executeCommands = async () => {
    try {
      const response = await axios.post('/execute', { commands: command.split('\n') });
      setOutput(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <textarea
        value={command}
        onChange={(e) => setCommand(e.target.value)}
        placeholder="Enter commands (one per line)"
        rows={5}
        required
      ></textarea>
      <button onClick={executeCommands}>Execute</button>
      <pre>
        {output.map((item, index) => (
          <div key={index}>
            <strong>{item.command}</strong>
            <br />
            {item.output}
            <br />
            <span>Exit Code: {item.code}</span>
          </div>
        ))}
      </pre>
    </div>
  );
};

export default CommandRunner;
