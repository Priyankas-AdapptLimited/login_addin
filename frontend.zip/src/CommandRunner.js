import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button } from 'react-bootstrap';
import axios from 'axios';
axios.defaults.baseURL = 'http://localhost:5000';
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';

const runtest = "Run Test";
const updatetoxray = "Update JIRA Xray";
const generatereport = "Generate Report";
const running = "Running";
const stopterminal = "Stop";
const testCommand = "npx wdio";
const xrayCommand = "sh ./import_results_cloud.sh";
const allureCommand = "sh ./runTest.sh";
let teststart = '';
let xraystart = '';
let allurestart = '';

const CommandRunner = () => {
  const [directory, setDirectory] = useState('/Users/adappt/Automation/my-app/automationScript');
  const [runbutton, setRunButton] = useState(runtest);
  const [report, setReport] = useState(generatereport);
  const [updatexray, setUpdateXray] = useState(updatetoxray);
  const [generatereportcommand, setGenerateReportCommand] = useState(allureCommand);
  const [runtestcommand, setRunTestCommand] = useState(testCommand);
  const [runxraycommand, setRunXayCommand] = useState(xrayCommand);
  const [output, setOutput] = useState('');
  // const [selectedFile, setSelectedFile] = useState(null);

  // const handleFileChange = (event) => {
  //   // setSelectedFile(event.target.files[0]);
  //   const file = event.target.files[0];
  //   const formData = new FormData();
  //   formData.append('file', file);

  //   fetch('http://localhost:5000/upload', {
  //     method: 'POST',
  //     body: formData,
  //   })
  //   .then((response) => response.text())
  //   .then((data) => {
  //     console.log(data); // Handle server response
  //   })
  //   .catch((error) => {
  //     console.error('Error uploading file:', error);
  //     // Handle error cases
  //   });
  // };
  // const handleDirectoryChange = (event) => {
  //   const selectedDirectory = event.target.result;
    
  //   // const filePath = URL.createObjectURL(selectedDirectory);
  //   console.log('File path:', selectedDirectory);
  //   // setDirectory(selectedDirectory);
  // };

  const executeCommand = async () => {
    // const userData = {
    //     directory: directory,
    //     command: command
    // };
    // const formData = new FormData();
    // formData.append('file', selectedFile);
    // // const response = await axios.post('/upload', formData);
    // console.log('response', selectedFile);
    setRunButton(running)
    try {

      const userData = {
        directory: directory,
        command: runtestcommand
      };
      const response = await axios.post('/execute', userData);
      setOutput(response.data.output);
      setRunButton(runtest)
    } catch (error) {
      console.error(error);
    }
  };
  const executeXrayReport = async() =>{
    setUpdateXray(running)
    const userData = {
      directory: directory,
      command: runxraycommand
    };
    try {
      const response = await axios.post('/execute', userData);
      setOutput(response.data.output);
      setUpdateXray(updatetoxray)
    } catch (error) {
      console.error(error);
    }

  }
  const executeAllureReport = async() =>{
    setReport(running)
    try {
      const userData = {
        directory: directory,
        command: generatereportcommand
      };
      const response = await axios.post('/execute', userData);
      setOutput(response.data.output);
      setReport(report)
    } catch (error) {
      console.error(error);
    }
  }

  const stopTerminal=async()=>{
    const userData = {
      directory: directory,
      command: 'exit'
    };
    try {
      const response = await axios.post('/stop', userData);
      setOutput(response.data.output);
    } catch (error) {
      console.error(error);
    }
  }

  if(runbutton==='Running' || output===''){
    teststart = "";
    xraystart = "true";
    allurestart = "true";
  }
  else if(updatexray==='Running'){
    teststart = "true";
    xraystart = "";
    allurestart = "true";
  }
  else if(report==='Running'){
    teststart = "true";
    xraystart = "true";
    allurestart = "";
  }else{
    teststart = "";
    xraystart = "";
    allurestart = "";
  }
  

  return (
    <div class="text-center mb-2">
        {/* <input
        type="file"
        webkitdirectory="true"
        onChange={handleDirectoryChange}
      /> */}
      {/* <input type="file" id="directoryInput" onChange={handleFileChange} /> */}
      {/* <Form.Control
        style={{width: "25%"}}
        className="mb-3"
        type="text"
        id="inputPassword5"
      /> */}
      {/* <Form.Group controlId="formFile" className="mb-3">
        <Form.Label>Default file input example</Form.Label>
        <Form.Control type="file" style={{width: "25%"}} />
      </Form.Group> */}
      {/* <input
        type="hidden"
        style={{width: "30%", fontSize:"14px"}}
        value={directory}
        onChange={(e) => setDirectory(e.target.value)}
        placeholder="Enter directory path"
        required
      />
      <input
        type="hidden"
        value={runtestcommand}
        onChange={(e) => setRunTestCommand(e.target.value)}
        placeholder="Enter command"
        required
      /> */}
      <div class="container">
        <Button variant="primary" className='button' disabled={teststart}  onClick={executeCommand}>{runbutton}</Button>
        <Button variant="primary" className='button' disabled={xraystart} onClick={executeXrayReport}>{updatexray}</Button>
        <Button variant="primary" className='button' disabled={allurestart}  onClick={executeAllureReport}>{report}</Button>
        {/* <Button variant="secondary" className='button' onClick={stopTerminal}>{stopterminal}</Button> */}
      </div>
      {/* <button onClick={executeCommand}>Start</button> */}
      <pre>{output}</pre>
    </div>
  );
};

export default CommandRunner;
