import React, { useState } from 'react';
import axios from 'axios';
axios.defaults.baseURL = 'http://localhost:5000';
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
const CommandRunner = () => {
  const [commands, setCommands] = useState('');
  const [output, setOutput] = useState([]);

  const executeCommands = async () => {
    try {
      const response = await axios.post('/execute', { commands: commands.split('\n') });
      const { output } = response.data;
      setOutput(output);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <textarea value={commands} onChange={(e) => setCommands(e.target.value)} placeholder="Enter commands..." rows={10} />
      <button onClick={executeCommands}>Run</button>
      {output.map(({ command, output }) => (
        <div key={command}>
          <h4>Command: {command}</h4>
          <pre>{output}</pre>
        </div>
      ))}
    </div>
  );
};

export default CommandRunner;
